clc, clear, close all
rng default
global initial_flag
%% Genetic Algotithm Optimization 15 iterations
initial_flag = 0;
options = optimoptions('ga','PlotFcn',{@gaplotbestf,@gaplotdistance});
for i=1:15
initial_flag = 0;
%CEC function-6 ,D=2
[X,Val,Exit_flg,Opr] = ga(@(x)benchmark_func(x,7),10,options)
Main_Val(i) = Val
Main_Exit_flag(i) = Exit_flg
Main_Opr(i) = Opr
% save visualizations to file
fname = sprintf('filename(%d).fig', i) ;
savefig(fname)
end
%% GA 15 iteration measures

Mean = mean(Main_val)
Std = std(Main_val)
